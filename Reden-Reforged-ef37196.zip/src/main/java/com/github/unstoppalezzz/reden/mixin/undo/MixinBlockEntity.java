package com.github.unstoppalezzz.reden.mixin.undo;

import com.github.unstoppalezzz.reden.access.BlockEntityInterface;
import com.github.unstoppalezzz.reden.mixinhelper.UndoMixinHelper;
import net.minecraft.core.BlockPos;
import net.minecraft.core.HolderLookup;
import net.minecraft.core.component.DataComponentMap;
import net.minecraft.core.component.DataComponentType;
import net.minecraft.core.component.DataComponents;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(BlockEntity.class)
public abstract class MixinBlockEntity implements BlockEntityInterface {
    @Shadow @Nullable protected Level level;
    @Final @Shadow protected BlockPos worldPosition;
    @Shadow private BlockState blockState;
    @Shadow private DataComponentMap components;
    //? if < 1.21.6 {
    /*@Shadow public abstract CompoundTag saveWithId(HolderLookup.Provider provider);
    *///?} else {
    @Shadow public abstract void saveWithId(net.minecraft.world.level.storage.ValueOutput par1);
    //?}

    @Unique CompoundTag lastSavedNbt = null;
    @Unique int lastSaveTime = 0;
    @Unique DataComponentMap lastComponents = null;

    @Override
    public void saveLastNbt$reden() {
        if (level != null && !level.isClientSide()) {
            if (lastSaveTime == level.getServer().getTickCount()) {
                return;
            }
            if (isComponentsValid(components)) {
                lastComponents = components;
            } else {
                try {
                    var vo = net.minecraft.world.level.storage.TagValueOutput.createWithContext(
                            net.minecraft.util.ProblemReporter.DISCARDING,
                            level.registryAccess()
                    );
                    this.saveWithId(vo);
                    lastSavedNbt = vo.buildResult();
                } catch (Throwable t) {
                }
            }
            lastSaveTime = level.getServer().getTickCount();
        }
    }

    @Unique
    private boolean isComponentsValid(DataComponentMap lastComponents) {
        return false;
    }

    @Override
    public @Nullable Object getLastSavedNbt$reden() {
        if (isComponentsValid(lastComponents)) {
            return lastComponents;
        } else if (lastSavedNbt != null) {
            return lastSavedNbt;
        } else {
            return null;
        }
    }

    @Inject(
            method = "setChanged()V",
            at = @At("HEAD")
    )
    private void onBlockEntityChanged(CallbackInfo ci) {
        if (level instanceof ServerLevel serverLevel) {
            UndoMixinHelper.postSetBlock(serverLevel, worldPosition, blockState, true);
        }
    }

    @Inject(
            method = "loadWithComponents",
            at = @At("TAIL")
    )
    private void onReadNbt(CallbackInfo ci) {
        if (lastSavedNbt == null && lastComponents == null) {
            if (isComponentsValid(components)) {
                lastComponents = components;
            } else if (level != null) {
                try {
                    var vo = net.minecraft.world.level.storage.TagValueOutput.createWithContext(
                            net.minecraft.util.ProblemReporter.DISCARDING,
                            level.registryAccess()
                    );
                    this.saveWithId(vo);
                    lastSavedNbt = vo.buildResult();
                } catch (Throwable t) {
                }
            }
        }
    }
}
