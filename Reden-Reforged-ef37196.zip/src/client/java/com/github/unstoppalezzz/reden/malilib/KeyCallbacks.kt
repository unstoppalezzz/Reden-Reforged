package com.github.unstoppalezzz.reden.malilib

import com.github.unstoppalezzz.reden.Reden
import com.github.unstoppalezzz.reden.network.Undo
import com.github.unstoppalezzz.reden.utils.multiver.Text
import com.github.unstoppalezzz.reden.utils.red
import fi.dy.masa.malilib.config.options.ConfigHotkey
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking
import net.minecraft.client.Minecraft

fun configureKeyCallbacks(mc: Minecraft) {
    REDEN_CONFIG_KEY.callback {
        mc.setScreenAndShow(GuiConfigs())
        true
    }
    UNDO_KEY.callback {
        if (mc.gameMode?.playerMode?.isCreative != true)
            return@callback false
        else
            ClientPlayNetworking.send(Undo(0))
        true
    }
    REDO_KEY.callback {
        if (mc.gameMode?.playerMode?.isCreative == true) {
            ClientPlayNetworking.send(Undo(1))
            true
        } else false
    }
}

private fun ConfigHotkey.callback(action: () -> Boolean) {
    keybind.setCallback { _, _ ->
        try {
            if (action()) {
//                onFunctionUsed(name)
                true
            } else false
        } catch (e: Exception) {
//            reportException(e)
//? if <= 1.21.1 {
            /*Minecraft.getInstance().player?.sendSystemMessage(Text.literal("Error when executing hotkey $name").red())
*///?} else {
            Minecraft.getInstance().player?.sendSystemMessage(Text.literal("Error when executing hotkey $name").red())
//?}
            false
        }
    }
}
